# flake8: noqa

# import apis into api package
from quepasa.api.default_api import DefaultApi

